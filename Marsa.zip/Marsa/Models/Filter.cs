﻿namespace Marsa.Models
{
    public class Filter
    {
        public string Area { get; set; }
    }
}